<?php

///BACKEND & PAGES


//### register class: /backend/class/regsiter/
$page_back['register_username'] = './backend/class/register/register.class.username.php';
$page_back['register_interets'] = './backend/class/register/register.class.interets.php';
$page_back['register_age'] = './backend/class/register/register.class.age.php';
$page_back['register_password'] = './backend/class/register/register.class.password.php';
$page_back['register_request'] = './backend/class/register/register.class.request.php';

//### register class: /backend/class/login



///DESIGN
$page_front['register'] = './pages/register.php';
$page_front['404'] = './pages/404.php';
$page_front['footer'] = './pages/footer.php';
$page_front['start'] = './pages/start.php';
$page_front['navbar'] = './pages/navbar.php';


?>