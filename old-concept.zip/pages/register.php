
<?php

///REGISTER FORM
include ('./backend/class/register/register.class.form.php');

///INSERT INTO DB
include ('./backend/class/register/register.class.interests.php');

///check input
include ('./backend/class/register/register.class.check.php');


?>  