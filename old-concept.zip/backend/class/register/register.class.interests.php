<?php

if(isset($_GET['insert'])){



    ///make local vars for register

    if (isset ($_REQUEST['user'])) {
        $getuser_reg = $_REQUEST['user'];
    } else {
        echo "";
    }
    
}
?>