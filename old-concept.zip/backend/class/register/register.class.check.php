<?php 

if(isset($_POST['user'])){

    echo "set";

} else {

echo "unset"; 

}



?>