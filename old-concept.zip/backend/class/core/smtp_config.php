<?php
$mailhost       = "smtp.gmail.com";  //SMTP Host name
$mailsmtpauth   = true;
$mailusername   = "chrischivlog@gmail.com"; // SMTP Login
$mailpassword   = "chrischivlo"; // SMTP Password
?>

hallo