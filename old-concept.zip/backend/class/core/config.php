<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "contenthub";
    $conn = new mysqli($servername, $username, $password, $dbname);
?>