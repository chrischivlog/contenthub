<?php 

/// USE THIS ONLY WITH PAGE SYSTEM

///CONFIGS
include('./backend/class/core/smtp_config.php');
include('./backend/class/core/config.php');

//class
include('./backend/class/core/core.redirect.class.php');
include('./backend/class/core/core.class.meta.php');


?>